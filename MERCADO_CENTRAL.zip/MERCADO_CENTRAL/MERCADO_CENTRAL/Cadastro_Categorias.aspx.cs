﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MERCADO_CENTRAL
{
    public partial class Cadastro_Categorias : System.Web.UI.Page
    {
        //Cria a string de conexão
        string strCnn;
        //Cria o sqlConnection
        SqlConnection objCnn;

        //Cria a string de Comando
        string strSelectCmd;
        //Cria o sqlCommand
        SqlCommand objCmd;

        //Cria o Adaptador
        SqlDataAdapter objAdp;

        //Cria o DataTable
        DataTable dtCategorias;







        protected void Page_Load(object sender, EventArgs e)
        {
            strCnn = "Data Source=(localdb)\\ProjectsV12;Initial Catalog=MERCADO_CENTRAL;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";

            strSelectCmd = "SELECT IDCATEGORIA, TIPO FROM CATEGORIA";

            //Instanciando o objeto de Conexão com o banco de dados
            objCnn = new SqlConnection(strCnn);

            //chama apenas na primeira carga da pagina
            if (!IsPostBack)
            {
                this.preencheGrid(strSelectCmd);
            }
        }


        private void preencheGrid(string strCommand)
        {

            //Instanciar o objeto de Comando
            objCmd = new SqlCommand(strCommand, objCnn);
            //Determinar o tipo do Comando
            objCmd.CommandType = CommandType.Text;

            //Abrir a conexão
            objCnn.Open();

            //Instanciar o DataAdapter
            objAdp = new SqlDataAdapter(objCmd);

            //Liberar o objeto de comando
            objCmd.Dispose();

            //Instanciando a Tabela Virtual(DataTable)
            dtCategorias = new DataTable();

            //Preencher a Tabela Virtual(DataTable)
            objAdp.Fill(dtCategorias);

            //Fechar a Conexão
            objCnn.Close();

            //Setar a fonte de dados do GridView
            this.gdvListaCategorias.DataSource = dtCategorias;

            //Fixar os dados no GridView
            this.gdvListaCategorias.DataBind();

        }

        protected void Button1_Cadastrar_Click(object sender, EventArgs e)
        {
            string strInsertCmd;

            if (txttipo.Text == "")
            {
                Response.Write("<script>alert('Digite um nome para a Categoria!');</script>");
            }
            else
            {
                strInsertCmd = string.Format("INSERT INTO CATEGORIAS (TIPO) VALUES ('{0}')", txttipo.Text);

                //Instanciando o objeto de Comando
                objCmd = new SqlCommand(strInsertCmd, objCnn);

                //Instanciar o objeto de Comando
                objCmd = new SqlCommand(strInsertCmd, objCnn);
                //Determinar o tipo do Comando
                objCmd.CommandType = CommandType.Text;

                //Abrir a conexão
                objCnn.Open();

                int auxiliar = objCmd.ExecuteNonQuery();

                objCnn.Close();

                //Executa o comando no banco de dados e retorna o numero de linhas afetadas.
                //Logo, se o comando for bem sucedido, o método ExecuteNonQuery retornará um valor maior que zero.
                if (auxiliar > 0)
                {
                    Response.Write("<script>alert('Inserção realizada com sucesso.');</script>");
                    this.preencheGrid(strSelectCmd);
                    LimparCampos();
                }
                else
                {
                    Response.Write("<script>alert('Inserção não realizada!');</script>");
                }
            }
        }

    }
}

